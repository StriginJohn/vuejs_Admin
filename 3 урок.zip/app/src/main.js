const $=require("jquery");

function getPagesList(){
$("h1").remove();
$.get("./api/api.php",(data)=>{
  data.forEach((file)=>{
    $("body").append("<h1>"+file+"</h1>");
  });
},"JSON");
}

getPagesList();


$("#deleteFile").click(()=>{
   $.post("./api/unlinkHtml.php",{
     "name":$("#fileName").val()
   }, (data) => {
     getPagesList();
     console.log(data);
   })
   .fail(()=>{
      alert("Такой страницы нет");
   })
})

$("#createFile").click(()=>{
   $.post("./api/newHtml.php",{
     "name":$("#fileName").val()
   }, (data) => {
     getPagesList();
   })
   .fail(()=>{
      alert("Такая страница уже существует");
   })
})
